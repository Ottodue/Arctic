package commands;





import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;


import commands.main;
import utils.Utils;

public class freeze implements CommandExecutor, Listener {
    private main main;
    public freeze(main main) {
        this.main = main;
    }



    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
    	if(sender.hasPermission("Screenshare.freeze")) {
    		if(args.length >= 2 && (args[1].equalsIgnoreCase("off") || args[1].equalsIgnoreCase("on"))) {
        if (!(args.length == 0 || Bukkit.getPlayerExact(args[0]) == null)) {
        		Player target = Bukkit.getServer().getPlayer(args[0]);
        		if(args[1].equalsIgnoreCase("off")) {
        			if(!(main.frozen.contains(target))) {
        				sender.sendMessage(Utils.chat(main.getConfig().getString("Messages.On_Player_already_off").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
        				return true;
        			}
        			main.frozen.remove(target);
                    sender.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.On_UnFreeze").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
                    target.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.Un_Freeze").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
                    return true;
        			
        		} else if(args[1].equalsIgnoreCase("on")) {
        			if(main.frozen.contains(target)) {
        				sender.sendMessage(Utils.chat(main.getConfig().getString("Messages.On_Player_already_on").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
        				return true;
        			}
        			main.frozen.add(target);
                    target.setAllowFlight(false);
                    sender.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.On_Freeze").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
                    target.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.Freeze").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
                    return true;
        		}
        	}
            sender.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.Specify_Player").replace("{USER}", sender.getName())));
            return true;
        } else if(args.length == 1) {
        if(!(Bukkit.getPlayerExact(args[0]) == null)) {
        
        Player target = Bukkit.getServer().getPlayer(args[0]);
        if (!(main.frozen.contains(target))) {
            main.frozen.add(target);
            target.setAllowFlight(false);
            sender.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.On_Freeze").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
            target.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.Freeze").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
            return true;
        } else {
            main.frozen.remove(target);
            sender.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.On_UnFreeze").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
            target.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.Un_Freeze").replace("{USER}", sender.getName()).replace("{TARGET}", args[0])));
            return true;
        }
    } else {
    	sender.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.Specify_Player").replace("{USER}", sender.getName())));
    	return true;
    }
        }
    		sender.sendMessage(Utils.chat(main.getConfig().getString("Prefix")) + Utils.chat(main.getConfig().getString("Messages.Specify_Player").replace("{USER}", sender.getName())));
    		return true;
    	}
		return true;
    }




   @EventHandler
    public void move(PlayerMoveEvent move)
    {
	   if(main.frozen.contains(move.getPlayer())) {
        Location from=move.getFrom();
        Location to=move.getTo();
        double x=Math.floor(from.getX());
        double z=Math.floor(from.getZ());
        if(Math.floor(to.getX())!=x||Math.floor(to.getZ())!=z)
        {
            x+=.5;
            z+=.5;
            move.getPlayer().teleport(new Location(from.getWorld(),x,from.getY(),z,from.getYaw(),from.getPitch()));
        }
    }
    }
     
    HashMap<String, Long> moveTimes = new HashMap<String, Long>();
    @EventHandler
    public void onMove(PlayerMoveEvent e) {

        Player p = e.getPlayer();
        if(main.frozen.contains(p)) {
        if(moveTimes.containsKey(p.getName())) {
            long oldTime = moveTimes.get(p.getName());
            long newTime = System.currentTimeMillis();
            if((newTime - oldTime) > (5 * 1000)) {
                moveTimes.remove(p.getName());
            }
        }
        else {
            moveTimes.put(p.getName(), System.currentTimeMillis());
            for (String op: main.getConfig().getStringList("Freeze_Message")) {
                p.sendMessage(Utils.chat(op));
            }
        }
    }
    	}
    @EventHandler
    public void onPlayerItemDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (main.frozen.contains(p)) {
            e.setCancelled(true);

        }
    }
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (main.frozen.contains(p)) {
            e.setCancelled(true);
            //TODO Remember to test this to make sure it works... (And removes chat)
        }

    }
    @EventHandler
    public void onPlayerQuitEvent(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (main.frozen.contains(p)) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), main.getConfig().getString("Command_On_Leave").replace("{USER}", p.getName()).replace("{DISPLAY_NAME}", p.getDisplayName()));
            //TODO get command from console to maybe BAN player?
        }
    }
    @EventHandler
    public void onHit(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player) {
            if (main.frozen.contains(e.getEntity())) {
                e.setCancelled(true);
            }
        }

    }
    @EventHandler
    public void PickupItem(PlayerPickupItemEvent e) {
        if (main.frozen.contains(e.getPlayer())) {
            e.setCancelled(true);
        }

    }
    @EventHandler
    public void onHit(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player) {
            e.setCancelled(true);
        }
    }
}