
package commands;


import java.io.File;
import java.util.ArrayList;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;





public class main extends JavaPlugin {
	
	  public ArrayList<Player> frozen = new ArrayList<>();
		
		public void onEnable() {
			saveDefaultConfig();
			File file = new File(getDataFolder(), "config.yml");
			
			if(!file.exists()) {
				getConfig().options().copyDefaults(true);
				saveConfig();
			}
		System.out.println("Plugin started");
		getServer().getPluginManager().registerEvents(new freeze(this), this);
		getCommand("freeze").setExecutor(new freeze(this));
	}
	public void onDisable() {
		System.out.println("Plugin disabled");
	}
	}

		