package utils;

import org.bukkit.ChatColor;

public class Utils { //Make a utils pacage so it is easier to make chat colors
	
	public static String chat (String s) {
		return ChatColor.translateAlternateColorCodes('&', s); //Return result XD
	}

}
