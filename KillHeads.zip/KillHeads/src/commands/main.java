
package commands;
import java.io.File;
import java.util.logging.Logger;

import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import net.milkbowl.vault.economy.Economy;

public class main extends JavaPlugin {
    
    private static final Logger log = Logger.getLogger("Minecraft");
    public static Economy econ = null;

    @Override
    public void onDisable() {
        log.info(String.format("[%s] Disabled Version %s", getDescription().getName(), getDescription().getVersion()));
    }

    @Override
    public void onEnable() {
        if (!setupEconomy() ) {
            log.severe(String.format("[%s] - Disabled due to no Vault dependency found! (Or it could be that you have no economy plugin)", getDescription().getName()));
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
		saveDefaultConfig();
		File file = new File(getDataFolder(), "config.yml");
		
		if(!file.exists()) {
			saveDefaultConfig();
		}
		System.out.println("Plugin started");
		getServer().getPluginManager().registerEvents(new sellhead(this), this);
		getServer().getPluginManager().registerEvents(new project(this), this);
		getCommand("heads").setExecutor(new project(this));
    }
    
    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        econ = rsp.getProvider();
        return econ != null;
    }
    
    
    public static Economy getEconomy() {
        return econ;
}
}
