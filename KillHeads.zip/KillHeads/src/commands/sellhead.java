package commands;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import net.milkbowl.vault.economy.EconomyResponse;
import utils.Utils;

public class sellhead implements Listener {
	private main main;
	public sellhead(main main) {
		this.main = main;
	}
	public static boolean isInt(String s) {
	    try {
	        Integer.parseInt(s);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
	public boolean isDouble(String value) {
	    try {
	        Double.parseDouble(value);
	        return true;
	    } catch (NumberFormatException e) {
	        return false;
	    }
	}
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onInteract(PlayerInteractEvent e) {

		final Player p = e.getPlayer();
				if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
					ItemStack item = p.getItemInHand();
					if (item.getType() == Material.SKULL_ITEM // Check that it's a skull item
							&& item.getData().getData() == 3 // Check that it's of type 3, a player skull
							&& item.getEnchantmentLevel(Enchantment.DURABILITY) == 100)
							{// Check that it has unbreaking 100 {
						e.setCancelled(true);
					double num = main.getConfig().getDouble("Payment");
					double Money = commands.main.econ.getBalance(p) - (num * commands.main.econ.getBalance(p)/100) ;
					if(commands.main.econ.getBalance(p) != 0) {
					EconomyResponse r = commands.main.econ.depositPlayer(p, Money);
		            if(r.transactionSuccess()) {
		            	if(p.getInventory().getItemInHand().getAmount() == 1) {
		            		p.setItemInHand(new ItemStack(Material.AIR));
		            	} else {
		            	p.getInventory().getItemInHand().setAmount(p.getInventory().getItemInHand().getAmount()-1);
		            	}
		            	p.sendMessage(Utils.chat(main.getConfig().getString("Messages.Sell_Message").replace("{user}", p.getName()).replace("{sell_money}", String.valueOf(Math.round(Money))).replace("{money}", String.valueOf(commands.main.econ.getBalance(p)))));
		            } else {
		                p.sendMessage(String.format("An error occured: %s", r.errorMessage));
		            }
					} else {
						p.sendMessage(main.getConfig().getString("Messages.No_Money").replace("{user}", p.getName()));
					}
							}
				}
	}
}