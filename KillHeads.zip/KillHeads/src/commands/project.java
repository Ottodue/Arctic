package commands;


import org.bukkit.Material;
import org.bukkit.SkullType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import utils.Utils;

public class project implements CommandExecutor, Listener {
	private main main;
	public project(main main) {
		this.main = main;
	}
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender.hasPermission(main.getConfig().getString("Permission"))) {
		if (!(sender instanceof Player)) {
			sender.sendMessage(Utils.chat(main.getConfig().getString("Messages.MustBePlayer_To_Execute_Command")));
            return true;
    }
		Player p = (Player) sender;
		if(args.length >= 2) {
		if(args[0].equalsIgnoreCase("set")) {
			if(isInt(args[1])) {
			main.getConfig().set("Percent", args[1]);
			p.sendMessage(Utils.chat(main.getConfig().getString("Messages.Success_on_SetProcentChance").replace("{procent}", args[1])));
		} else {
			p.sendMessage(Utils.chat(main.getConfig().getString("Messages.Int_NoString")));
		}
		} else {
			p.sendMessage(Utils.chat(main.getConfig().getString("Messages.Invalid_Args")));
		}
} else {
	p.sendMessage(Utils.chat(main.getConfig().getString("Messages.No_Args")));
}
		}
		return true;
	}
	public static boolean isInt(String s) {
	    try {
	        Integer.parseInt(s);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
    @EventHandler
    public void onKill(PlayerDeathEvent e) {
    	if(e.getEntity() instanceof Player) {
    	Random r = new Random();
    	int Low = 1;
    	int High = 100;
    	int Result = r.nextInt(High-Low) + Low;
    	double num = main.getConfig().getDouble("Percent");
    	if((num >= Result)) {
    	String killed = e.getEntity().getName();
    	Player killer = e.getEntity().getKiller();
    	ItemStack stats = new ItemStack(Material.SKULL_ITEM, 1, (short) SkullType.PLAYER.ordinal());
    	SkullMeta statmeta = (SkullMeta) stats.getItemMeta();
    	System.out.println(!((main.getConfig().getString("Messages.Head_Owner")) == ""));
    	System.out.print((main.getConfig().getString("Messages.Head_Owner")));
    	if(!((main.getConfig().getString("Messages.Head_Owner")).equals(""))){
    		statmeta.setOwner(main.getConfig().getString("Messages.Head_Owner").replace("{killed}", killed).replace("{killer}", killer.getName()));
    	} else {
    		statmeta.setOwner(killed);
    	}
	    	statmeta.setDisplayName(main.getConfig().getString("Messages.Head_Display_Name").replace("{killed}", killed));
	    	statmeta.addEnchant(Enchantment.DURABILITY,100, true);
	    	List<String> OPlist = main.getConfig().getStringList("lore");
	    	if(OPlist.isEmpty() == false) {
	    	List<String> Op2 = new ArrayList<String>();;
	    	for(String op : OPlist) {
				Op2.add(op.replace("{killer}", killer.getName()).replace("{killed}", killed));
				}
    	statmeta.setLore(Op2);
    	stats.setItemMeta(statmeta);
    	killer.getInventory().addItem(stats);
    	killer.sendMessage(Utils.chat(main.getConfig().getString("Messages.Success_AddHead").replace("{killer}", killer.getName()).replace("{killed}", killed)));
    	} else {
    		stats.setItemMeta(statmeta);
        	killer.getInventory().addItem(stats);
        	killer.sendMessage(Utils.chat(main.getConfig().getString("Messages.Success_AddHead").replace("{killer}", killer.getName()).replace("{killed}", killed)));
    	}
    	}
    	    }
    	    }
}
